package com.example.usuario.bloody_army;

/**
 * Clase que almacenara las preguntas.
 */
public class Preguntas {

    /**
     * La Pregunta.
     */
    public String pregunta;

    /**
     * La Respuesta 1.
     */
    public String respuesta1;

    /**
     * La Respuesta 2.
     */
    public String respuesta2;

    /**
     * La Respuesta3.
     */
    public String respuesta3;

    /**
     * La Respuesta 4.
     */
    public String respuesta4;

//  Creamos el constructor por parametros de la clase.
    /**
     * Constructor por parametros de la clase preguntas.
     *
     * @param pregunta La pregunta a realizar.
     * @param respuesta1 La primera opcion a esa pregunta.
     * @param respuesta2 La segunda opcion a esa pregunta.
     * @param respuesta3 La tercera opcion a esa pregunta.
     * @param respuesta4 La cuarta opcion a esa pregunta.
     */
    public Preguntas(String pregunta, String respuesta1, String respuesta2, String respuesta3, String respuesta4) {
        this.pregunta = pregunta;
        this.respuesta1 = respuesta1;
        this.respuesta2 = respuesta2;
        this.respuesta3 = respuesta3;
        this.respuesta4 = respuesta4;
    }

    /**
     * Instanciamos la clase Preguntas.
     */
//  Creamos el constructor por defecto de la clase.
    public Preguntas(){

    }

    //  Metodos getters y setters.

    /**
     * Obtiene la pregunta.
     *
     * @return la pregunta
     */
    public String getPregunta() {
        return pregunta;
    }

    /**
     *  Setea la pregunta.
     *
     * @param pregunta la pregunta
     */
    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    /**
     * Obtiene la respuesta 1.
     *
     * @return la respuesta 1
     */
    public String getRespuesta1() {
        return respuesta1;
    }

    /**
     * Setea la respuesta 1.
     *
     * @param respuesta1 la respuesta 1
     */
    public void setRespuesta1(String respuesta1) {
        this.respuesta1 = respuesta1;
    }

    /**
     * Obtiene la respuesta 2.
     *
     * @return la respuesta 2
     */
    public String getRespuesta2() {
        return respuesta2;
    }

    /**
     * Setea la respuesta 2.
     *
     * @param respuesta2 la respuesta 2
     */
    public void setRespuesta2(String respuesta2) {
        this.respuesta2 = respuesta2;
    }

    /**
     * Obtiene la respuesta 3.
     *
     * @return la respuesta 3
     */
    public String getRespuesta3() {
        return respuesta3;
    }

    /**
     * Setea la respuesta 3.
     *
     * @param respuesta3 la respuesta 3
     */
    public void setRespuesta3(String respuesta3) {
        this.respuesta3 = respuesta3;
    }

    /**
     * Obtiene la respuesta 4.
     *
     * @return la respuesta 4
     */
    public String getRespuesta4() {
        return respuesta4;
    }

    /**
     * Setea la respuesta 4.
     *
     * @param respuesta4 la respuesta 4
     */
    public void setRespuesta4(String respuesta4) {
        this.respuesta4 = respuesta4;
    }
}
