package com.example.usuario.bloody_army;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.usuario.bloody_army.CategoriasDiccionario.PgmActivity;

public class DiccionarioActivity extends AppCompatActivity {

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diccionario);

        ActionBar actionBar = getSupportActionBar();


        actionBar.setTitle("Diccionario");

    }

    public void abrirPgmActivity(View view) {
        Intent i = new Intent(DiccionarioActivity.this, PgmActivity.class);
        startActivity(i);
    }
}
