package com.example.usuario.bloody_army.Chat;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.usuario.bloody_army.R;
import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class AdaptadorMensaje extends RecyclerView.Adapter<AdaptadorMensaje.AdaptadorMensajeViewHolder> {

    Context contexto;
    List<Mensaje> mensajes;
    DatabaseReference mensajebd;

    public AdaptadorMensaje(Context contexto, List<Mensaje> mensajes, DatabaseReference mensajebd) {
        this.contexto = contexto;
        this.mensajes = mensajes;
        this.mensajebd = mensajebd;

    }

    @NonNull
    @Override
    public AdaptadorMensajeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(contexto).inflate(R.layout.item_mensaje, viewGroup,false);
        return new AdaptadorMensajeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorMensajeViewHolder adaptadorMensajeViewHolder, int i) {
        Mensaje mensaje = mensajes.get(i);

        if (mensaje.getNombre().equals(AllMethods.nombre)){
            adaptadorMensajeViewHolder.titulo.setText("Tu: " + mensaje.getMensaje());
            adaptadorMensajeViewHolder.titulo.setGravity(Gravity.START);
            adaptadorMensajeViewHolder.l1.setBackgroundColor(Color.parseColor("#000000"));
        } else {
            adaptadorMensajeViewHolder.titulo.setText(mensaje.getNombre() + ":" + mensaje.getMensaje());
            adaptadorMensajeViewHolder.borrar.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mensajes.size();
    }

    public class AdaptadorMensajeViewHolder extends RecyclerView.ViewHolder {

        TextView titulo;
        ImageButton borrar;
        LinearLayout l1;

        public AdaptadorMensajeViewHolder(@NonNull View itemView) {

            super(itemView);

            titulo = (TextView) itemView.findViewById(R.id.titulo);
            borrar = (ImageButton) itemView.findViewById(R.id.borrar);
            l1 = (LinearLayout) itemView.findViewById(R.id.l1Mensaje);

            borrar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mensajebd.child(mensajes.get(getAdapterPosition()).getKey()).removeValue();
                }
            });
        }
    }
}
