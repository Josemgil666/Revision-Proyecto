package com.example.usuario.bloody_army.Chat;

public class AllMethods {

    public static String nombre = "";

}
