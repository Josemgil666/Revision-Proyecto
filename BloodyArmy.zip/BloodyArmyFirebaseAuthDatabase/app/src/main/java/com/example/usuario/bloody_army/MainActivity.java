package com.example.usuario.bloody_army;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

/**
 * Clase Main.
 *
 * Esta es la actividad principal (Launcher).
 *
 * @author Jose Manuel Gil
 * @version 3.0
 */
public class MainActivity extends AppCompatActivity {

    TextInputEditText emailLogin;
    TextInputEditText contrasenaLogin;
    ProgressBar barraProgreso;

    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();

        final Button registrate = (Button) findViewById(R.id.botonRegistrate);
        final ImageView imagen;
        //final Button entrar = (Button) findViewById(R.id.botonLogin);
        barraProgreso = (ProgressBar) findViewById(R.id.progresoLogin);
        emailLogin = (TextInputEditText) findViewById(R.id.campo_email);
        contrasenaLogin = (TextInputEditText) findViewById(R.id.campo_contraseña);

        imagen = (ImageView) findViewById(R.id.logo);

        imagen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rotarImagen(imagen);
            }
        });

        //  Se ejecutara cuando se haga clic en el boton "registrate".
        registrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, RegistroActivity.class);
                startActivity(i);
            }
        });

    }

    /*private void iniciarSesion(String email, String pass){

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this,"Sesión iniciada con éxito", Toast.LENGTH_LONG).show();
                    Intent i = new Intent(MainActivity.this, DosActivity.class);
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this,"Algo ha fallado. Inténtelo de nuevo", Toast.LENGTH_LONG).show();
                }
            }
        });
    }*/

    public void LoginUsuario(View view){
        barraProgreso.setVisibility(View.VISIBLE);

        String email = emailLogin.getText().toString();
        String contraseña = contrasenaLogin.getText().toString();

        if (!email.equals("") && !contraseña.equals("")){
            auth.signInWithEmailAndPassword(email, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        barraProgreso.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this, "Sesión iniciada", Toast.LENGTH_SHORT).show();

                        Intent i = new Intent(MainActivity.this, DosActivity.class);
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                        barraProgreso.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    private void rotarImagen(View view){
        RotateAnimation animation = new RotateAnimation(0, 360,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f);

        animation.setDuration(1000);
        animation.setRepeatCount(1);
        animation.setRepeatMode(Animation.REVERSE);
        view.startAnimation(animation);
    }

    public void ContrasenaOlvidada(View view){
        final AlertDialog.Builder alerta = new AlertDialog.Builder(MainActivity.this, R.style.MiAlertDialogStyle);

        LinearLayout contenedor = new LinearLayout(MainActivity.this);
        contenedor.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        ip.setMargins(50,0,50,100);

        final EditText entrada = new EditText(MainActivity.this);
        entrada.setLayoutParams(ip);
        entrada.setGravity(Gravity.TOP|Gravity.START);
        entrada.setInputType(InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        entrada.setLines(1);
        entrada.setMaxLines(1);

        contenedor.addView(entrada,ip);

        alerta.setMessage("Introduce tu email");
        alerta.setTitle("Recuperar contraseña");
        alerta.setView(contenedor);

        alerta.setPositiveButton("Enviar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, int which) {
                String emailRegistrado = entrada.getText().toString();

                auth.sendPasswordResetEmail(emailRegistrado).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            dialog.dismiss();
                            Toast.makeText(MainActivity.this, "Email de recuperación enviado", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        alerta.show();

    }

}