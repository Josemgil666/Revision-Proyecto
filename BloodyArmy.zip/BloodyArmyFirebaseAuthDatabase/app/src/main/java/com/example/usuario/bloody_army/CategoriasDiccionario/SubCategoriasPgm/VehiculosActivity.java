package com.example.usuario.bloody_army.CategoriasDiccionario.SubCategoriasPgm;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.usuario.bloody_army.Adaptador.MiAdaptador;
import com.example.usuario.bloody_army.Listener.IFirebaseCargaFinalizada;
import com.example.usuario.bloody_army.Modelo.Elemento;
import com.example.usuario.bloody_army.R;
import com.example.usuario.bloody_army.Transformador.TransformadorPagina;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class VehiculosActivity extends AppCompatActivity implements IFirebaseCargaFinalizada, ValueEventListener {

    ViewPager viewPager;
    MiAdaptador adaptador;

    DatabaseReference vehiculos;

    IFirebaseCargaFinalizada iFirebaseCargaFinalizada;

    List<Elemento> listaArmas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pgm_vehiculos);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Primera Guerra Mundial - Vehiculos");

        vehiculos = FirebaseDatabase.getInstance().getReference("PgmVehiculos");

        iFirebaseCargaFinalizada = this;

        cargarVehiculo();

        viewPager = (ViewPager) findViewById(R.id.view_pager);
        viewPager.setPageTransformer(true, new TransformadorPagina());

    }

    private void cargarVehiculo() {

        vehiculos.addValueEventListener(this);
    }

    public void onFirebaseLoadSuccess(List<Elemento> listaElemento) {
        adaptador = new MiAdaptador(this, listaElemento);
        adaptador.comprobarLayout("general");
        viewPager.setAdapter(adaptador);
    }

    public void onFirebaseLoadFailed(String message) {
        Toast.makeText(this, "" + message, Toast.LENGTH_SHORT).show();
    }

    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

        List<Elemento> listaArmas = new ArrayList<>();

        for(DataSnapshot armaSnapshot:dataSnapshot.getChildren())
            listaArmas.add(armaSnapshot.getValue(Elemento.class));
        iFirebaseCargaFinalizada.onFirebaseLoadSuccess(listaArmas);
    }

    public void onCancelled(@NonNull DatabaseError databaseError) {
        iFirebaseCargaFinalizada.onFirebaseLoadFailed(databaseError.getMessage());
    }

    protected void onDestroy() {
        vehiculos.removeEventListener(this);
        super.onDestroy();
    }

    protected void onResume() {
        super.onResume();
        vehiculos.addValueEventListener(this);
    }

    protected void onStop() {
        vehiculos.removeEventListener(this);
        super.onStop();
    }
}
