package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.usuario.bloody_army.Chat.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistroActivity extends AppCompatActivity {

    TextInputEditText emailRegistro;
    TextInputEditText contrasenaRegistro;
    TextInputEditText nombreRegistro;
    ProgressBar barraProgresoRegistro;
    ImageView imagen;

    DatabaseReference reference;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        // Ocultar la barra superior
        getSupportActionBar().hide();

        emailRegistro = (TextInputEditText) findViewById(R.id.emailRegistro);
        contrasenaRegistro = (TextInputEditText) findViewById(R.id.contraseñaRegistro);
        nombreRegistro = (TextInputEditText) findViewById(R.id.nombreUsuarioRegistro);
        barraProgresoRegistro = (ProgressBar) findViewById(R.id.progresoRegistro);

        imagen = (ImageView) findViewById(R.id.logo);

        imagen.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                rotarImagen(imagen);
            }
        });

        auth = FirebaseAuth.getInstance();
        reference = FirebaseDatabase.getInstance().getReference().child("Usuarios");

    }

    public void registrarUsuario(View view){
        barraProgresoRegistro.setVisibility(View.VISIBLE);
        final String email = emailRegistro.getText().toString();
        final String contraseña = contrasenaRegistro.getText().toString();
        final String nombre = nombreRegistro.getText().toString();

        if (!email.equals("") && !contraseña.equals("") && contraseña.length()>6){
            auth.createUserWithEmailAndPassword(email,contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){

                        // Insertar los valores en Firebase
                        FirebaseUser usuarioFirebase = auth.getCurrentUser();
                        Usuario usuario = new Usuario();
                        usuario.setNombre(nombre);
                        usuario.setEmail(email);

                        reference.child(usuarioFirebase.getUid()).setValue(usuario).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(RegistroActivity.this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show();

                                    barraProgresoRegistro.setVisibility(View.GONE);
                                    finish();
                                    Intent i = new Intent(RegistroActivity.this, DosActivity.class);
                                    startActivity(i);

                                }else {
                                    barraProgresoRegistro.setVisibility(View.GONE);
                                    Toast.makeText(RegistroActivity.this, "El usuario no ha podido crearse", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });
        }

    }

    public void volverLogin(View view){
        Intent i = new Intent(RegistroActivity.this, MainActivity.class);
        startActivity(i);
    }

    private void rotarImagen(View view){
        RotateAnimation animation = new RotateAnimation(0, 360,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f);

        animation.setDuration(1000);
        animation.setRepeatCount(1);
        animation.setRepeatMode(Animation.REVERSE);
        view.startAnimation(animation);
    }
}
