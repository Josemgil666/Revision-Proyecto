package com.example.usuario.bloody_army.CategoriasDiccionario.SubCategoriasPgm;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.usuario.bloody_army.Adaptador.MiAdaptador;
import com.example.usuario.bloody_army.Listener.IFirebaseCargaFinalizada;
import com.example.usuario.bloody_army.Modelo.Elemento;
import com.example.usuario.bloody_army.R;
import com.example.usuario.bloody_army.Transformador.TransformadorPagina;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ArmasActivity extends AppCompatActivity implements IFirebaseCargaFinalizada, ValueEventListener {

    ViewPager viewPager;
    MiAdaptador adaptador;

    DatabaseReference armas;

    IFirebaseCargaFinalizada iFirebaseCargaFinalizada;

    List<Elemento> listaArmas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pgm_armas);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Primera Guerra Mundial - Armas");

        armas = FirebaseDatabase.getInstance().getReference("PgmArmas");

        iFirebaseCargaFinalizada = this;

        cargarArma();

        viewPager = (ViewPager) findViewById(R.id.view_pager);
        viewPager.setPageTransformer(true, new TransformadorPagina());

    }

    private void cargarArma() {

        armas.addValueEventListener(this);

    }

    @Override
    public void onFirebaseLoadSuccess(List<Elemento> listaElemento) {
        adaptador = new MiAdaptador(this, listaElemento);
        adaptador.comprobarLayout("general");
        viewPager.setAdapter(adaptador);
    }

    @Override
    public void onFirebaseLoadFailed(String message) {
        Toast.makeText(this, "" + message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

        List<Elemento> listaArmas = new ArrayList<>();

        for(DataSnapshot armaSnapshot:dataSnapshot.getChildren())
            listaArmas.add(armaSnapshot.getValue(Elemento.class));
        iFirebaseCargaFinalizada.onFirebaseLoadSuccess(listaArmas);
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {
        iFirebaseCargaFinalizada.onFirebaseLoadFailed(databaseError.getMessage());
    }

    @Override
    protected void onDestroy() {
        armas.removeEventListener(this);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        armas.addValueEventListener(this);
    }

    @Override
    protected void onStop() {
        armas.removeEventListener(this);
        super.onStop();
    }
}
