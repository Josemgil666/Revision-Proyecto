package com.example.usuario.bloody_army;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.usuario.bloody_army.Adaptador.MiAdaptador;
import com.example.usuario.bloody_army.Listener.IFirebaseCargaFinalizada;
import com.example.usuario.bloody_army.Modelo.Elemento;
import com.example.usuario.bloody_army.Transformador.TransformadorPaginaVertical;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class NoticiasActivity extends AppCompatActivity implements IFirebaseCargaFinalizada, ValueEventListener {

    ViewPager viewPager;
    MiAdaptador adaptador;

    DatabaseReference noticias;

    IFirebaseCargaFinalizada iFirebaseCargaFinalizada;

    List<Elemento> listaNoticias = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticias);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Noticias");

        noticias = FirebaseDatabase.getInstance().getReference("Noticias");

        iFirebaseCargaFinalizada = this;

        cargarNoticias();

        viewPager = (ViewPager) findViewById(R.id.view_pager);
        viewPager.setPageTransformer(true, new TransformadorPaginaVertical());

    }

    private void cargarNoticias() {

        noticias.addValueEventListener(this);
    }

    public void onFirebaseLoadSuccess(List<Elemento> listaElemento) {
        adaptador = new MiAdaptador(this, listaElemento);
        adaptador.comprobarLayout("noticias");
        viewPager.setAdapter(adaptador);
    }

    public void onFirebaseLoadFailed(String message) {
        Toast.makeText(this, "" + message, Toast.LENGTH_SHORT).show();
    }

    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

        List<Elemento> listaNoticias = new ArrayList<>();

        for(DataSnapshot armaSnapshot:dataSnapshot.getChildren())
            listaNoticias.add(armaSnapshot.getValue(Elemento.class));
        iFirebaseCargaFinalizada.onFirebaseLoadSuccess(listaNoticias);
    }

    public void onCancelled(@NonNull DatabaseError databaseError) {
        iFirebaseCargaFinalizada.onFirebaseLoadFailed(databaseError.getMessage());
    }

    protected void onDestroy() {
        noticias.removeEventListener(this);
        super.onDestroy();
    }

    protected void onResume() {
        super.onResume();
        noticias.addValueEventListener(this);
    }

    protected void onStop() {
        noticias.removeEventListener(this);
        super.onStop();
    }
}
