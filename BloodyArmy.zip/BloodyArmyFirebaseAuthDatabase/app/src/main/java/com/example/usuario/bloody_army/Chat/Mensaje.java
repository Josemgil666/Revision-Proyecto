package com.example.usuario.bloody_army.Chat;

public class Mensaje {

    String mensaje;
    String nombre;
    String key;

    public Mensaje(){

    }

    public Mensaje(String mensaje, String nombre) {
        this.mensaje = mensaje;
        this.nombre = nombre;
        this.key = key;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String toString(){
        return "Mensaje{"+
                "Mensaje='"+ mensaje + '\''+
                ", nombre = '"+ nombre + '\''+
                ", key = '"+ key + '\''+
                '}';

    }
}
