package com.example.usuario.bloody_army.Chat;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.usuario.bloody_army.MainActivity;
import com.example.usuario.bloody_army.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity implements View.OnClickListener {

    FirebaseAuth auth;
    FirebaseDatabase database;
    DatabaseReference mensajebd;
    AdaptadorMensaje adaptadorMensaje;
    Usuario usuario;
    List<Mensaje> mensajes;

    RecyclerView contMensajes;
    EditText enviarMensaje;
    ImageButton imgEnviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Chat");

        init();

    }

    private void init() {
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        usuario = new Usuario();

        contMensajes = (RecyclerView) findViewById(R.id.recyclerMensajes);
        enviarMensaje = (EditText) findViewById(R.id.mensajeAEnviar);
        imgEnviar = (ImageButton) findViewById(R.id.imgEnviar);
        imgEnviar.setOnClickListener(this);
        mensajes = new ArrayList<>();
    }

    public void onClick(View v) {
        if (!TextUtils.isEmpty(enviarMensaje.getText().toString())){
            Mensaje mensaje = new Mensaje(enviarMensaje.getText().toString(),usuario.getNombre());
            enviarMensaje.setText("");
            mensajebd.push().setValue(mensaje);
        }else {
            Toast.makeText(this, "No se puede enviar un mensaje vacío", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_cerrarSesion){
            auth.signOut();

            Toast.makeText(ChatActivity.this, "Tu sesión se ha cerrado correctamente", Toast.LENGTH_SHORT).show();

            new android.os.Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(ChatActivity.this, MainActivity.class);
                    startActivity(i);
                }
            }, 2000);

        }

        return super.onOptionsItemSelected(item);

    }

    protected void onStart() {

        super.onStart();
        final FirebaseUser usuarioActual = auth.getCurrentUser();

        usuario.setUserId(usuarioActual.getUid());
        usuario.setEmail(usuarioActual.getEmail());

        database.getReference("Usuarios").child(usuarioActual.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                usuario = dataSnapshot.getValue(Usuario.class);
                usuario.setUserId(usuarioActual.getUid());
                AllMethods.nombre = usuario.getNombre();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mensajebd = database.getReference("Mensajes");
        mensajebd.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Mensaje mensaje = dataSnapshot.getValue(Mensaje.class);
                mensaje.setKey(dataSnapshot.getKey());
                mensajes.add(mensaje);
                displayMensajes(mensajes);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Mensaje mensaje = dataSnapshot.getValue(Mensaje.class);
                mensaje.setKey(dataSnapshot.getKey());

                List<Mensaje> newMensajes = new ArrayList<Mensaje>();

                for (Mensaje m: mensajes){
                    if (m.getKey().equals(mensaje.getKey())){
                        newMensajes.add(mensaje);
                    }else {
                        newMensajes.add(m);
                    }
                }

                mensajes = newMensajes;

                displayMensajes(mensajes);

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                Mensaje mensaje = dataSnapshot.getValue(Mensaje.class);

                mensaje.setKey(dataSnapshot.getKey());

                List<Mensaje> newMensajes = new ArrayList<Mensaje>();

                for (Mensaje m: mensajes){
                    if (!m.getKey().equals(mensaje.getKey())){
                        newMensajes.add(m);
                    }
                }

                mensajes = newMensajes;

                displayMensajes(mensajes);

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    protected void onResume() {
        super.onResume();
        mensajes = new ArrayList<>();


    }

    private void displayMensajes(List<Mensaje> mensajes) {
        contMensajes.setLayoutManager(new LinearLayoutManager(ChatActivity.this));
        adaptadorMensaje = new AdaptadorMensaje(ChatActivity.this,mensajes,mensajebd);
        contMensajes.setAdapter(adaptadorMensaje);
    }

}
