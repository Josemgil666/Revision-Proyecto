package com.example.usuario.bloody_army.Listener;

import com.example.usuario.bloody_army.Modelo.Elemento;

import java.util.List;

public interface IFirebaseCargaFinalizada {

    void onFirebaseLoadSuccess(List<Elemento>listaElemento);

    void onFirebaseLoadFailed(String message);

}
