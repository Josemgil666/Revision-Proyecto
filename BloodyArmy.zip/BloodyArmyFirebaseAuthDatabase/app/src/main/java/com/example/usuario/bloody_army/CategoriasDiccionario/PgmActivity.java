package com.example.usuario.bloody_army.CategoriasDiccionario;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.usuario.bloody_army.CategoriasDiccionario.SubCategoriasPgm.ArmasActivity;
import com.example.usuario.bloody_army.CategoriasDiccionario.SubCategoriasPgm.VehiculosActivity;
import com.example.usuario.bloody_army.R;

public class PgmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pgm);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Primera Guerra Mundial");

    }

    public void abrirArmasActivity(View view) {
        Intent i = new Intent(PgmActivity.this, ArmasActivity.class);
        startActivity(i);
    }

    public void abrirVehiculosActivity(View view) {
        Intent i = new Intent(PgmActivity.this, VehiculosActivity.class);
        startActivity(i);
    }

}
