package com.example.usuario.bloody_army;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Actividad que se lanzara al completar las preguntas.
 */
public class EnhorabuenaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enhorabuena);

        //  OCULTAR ACTIONBAR
        getSupportActionBar().hide();

        Button entrar = (Button) findViewById(R.id.botonEntrar);

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //  Se encarga de pasar a la siguiente activity.
                Intent i = new Intent(EnhorabuenaActivity.this, MenuActivity.class);
                startActivity(i);

            }
        });

    }

    //  METODO QUE CONTROLA EL BOTON RETROCEDER EN EL MOVIL,
    //  SI LO DEJAMOS VACIO ORDENA QUE NO HAGA NADA
    /**
     * Metodo que se ejecutara cuando el usuario pulse el boton de retroceder en el terminal.
     */
    public void onBackPressed(){

    }

}
